package model.Exceptions;

public class ItemNotFoundException extends Exception {
    
}
