package model.Exceptions;

public class DuplicateItemException extends Exception {
    
}
