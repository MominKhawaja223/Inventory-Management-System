package model;

public class POItem {
	public Inventory inventory;
	public InventoryItem product;

}
